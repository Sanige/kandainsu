<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Kanda International</title>
<link href='http://fonts.googleapis.com/css?family=Cabin:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/main.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
<![endif]-->
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	<div class="container">
		<div class="navbar-header">
	    	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#kanda-nav">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
	      	</button>
	     	<a class="navbar-brand" href="/">
	     		<img src="images/logo-img.png" alt="Kanda International Insurance Brokers">
	     	</a>
	    </div>
		<div class="collapse navbar-collapse" id="kanda-nav">
			<ul class="nav navbar-nav navbar-right" id="menu">
				<li data-menuanchor="home"><a href="#home"><span>Home</span></a></li>
				<li data-menuanchor="whykanda"><a href="#whykanda"><span>Why Kanda</span></a></li>
				<li data-menuanchor="aboutus"><a href="#aboutus"><span>About Us</span></a></li>
				<li data-menuanchor="services"><a href="#services"><span>Services</span></a></li>
				<li data-menuanchor="ourstaff"><a href="#ourstaff"><span>Our Staff</span></a></li>
				<li data-menuanchor="contactus"><a href="#contactus"><span>Contact Us</span></a></li>
			</ul>
		</div>
	</div>
</nav>
<div id="loading" class="loading-site">
	<div class="spinner"></div>
</div>
<div id="kanda">
<section class="section home-section" id="home">
	<div class="container" id="intro">
		<div class="row">
			<div class="col-md-12">
				<h1><small>Welcome to </small> Kanda International</h1>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<p>We offer a wide range of Insurance, Products and Services to assist our valuable customers locally and worldwide. Kanda International Limited commenced operations in early January 2003 as Kanda International Insurance Brokers and Risk Consultants.</p>
			</div>
			<div class="col-md-6">
				<p>Kanda is licensed as a General Insurance Broker by the Government under the Insurance Act 1995. We are dynamic customer oriented organisation that is drive by a passion for delivering service with integrity to our customers.</p>
			</div>
		</div>
	</div>
	<div id="kanda-home" class="carousel kanda-home carousel-fade" data-ride="carousel">
		<div class="carousel-inner">
			<div class="item active" style="background-image: url(images/home-bg.jpg);"></div>
			<div class="item" style="background-image: url(images/7.jpg);"></div>
		</div>
	</div>
</section>
<section class="section why-section" id="why">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<h2>Why Kanda International</h2>
			</div>
		</div>
		<div class="clearfix why-box">
			<div class="row">
				<div class="box-w col-md-4">
					<div class="box">
						We are insurance brokers and we work for our clients NOT for the insurance companies. Hence, you get the best cover that you need.
					</div>
				</div>
				<div class="box-w col-md-8">
					<div class="box">
						We are able to place cover on your behalf with a wide range of insurance companies and underwriting agencies locally and/or globally. You get a choice, without the need to run around Insurance Companies.
					</div>
				</div>
			</div>
			<div class="row">
				<div class="box-w col-md-4">
					<div class="box">
						You get a peace of mind knowing that we will process and manage your claims professionally using our experiences, skill and resources.
					</div>
				</div>
				<div class="box-w col-md-4">
					<div class="box">
						We are always abreast with the global insurance market and latest information innovations in providing enhanced Insurance Produts. 
					</div>
				</div>
				<div class="box-w col-md-4">
					<div class="box">
						Our International Network with a string of Partners including <a href="http://www.willis.com" target="_blank">Willis International</a> and <a href="http://www.jlta.com.au" target="_blank">Jaydine Lloyd Thompson</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section about-section" id="about">
	<div class="slide">
		<div class="about-content">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<p class="lead">We are Insurance Brokers who can save you time, money and worry.</p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						<p>Just like an accountant or lawyer who provides you with impartial professional advice based on years of training and experience. A qualified broker can do the same with your insurance. When arranging insurance, many people take shortcuts without seeking proper advice, understanding the fine print or considering whether they are getting value for money. Often they are disappointed when their insurance doesn't come to the rescue.</p>
					</div>
					<div class="col-md-4">
						<p>Whether its home, car, life or business insurance, brokers provide advice and assistance to make sure you are properly protected. We have excess to varieties of policies because we deal with a range of insurance companies. Kanda International as a professional broker will be aware of the benefits, exclusions and costs of the competing policies on the market. We will also help arrange and place the cover and often provide advice on how to make.</p>
					</div>
					<div class="col-md-4">
						<p>the most of your insurance budget. Using us would not necessarily cost more. Often it costs less because we have the knowledge of the insurance market and the ability to negotiated competitive premiums on your behalf. We will be obliged to advise you of fees charged for services provided for you.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="slide">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<h2>Our Goal</h2>
					<p>Our goal is to create a long-term value for shareholders by producing superior sustained return.</p>
				</div>
				<div class="col-md-4">
					<h2>Our Vision</h2>
					<p>Our vision is to be reputable Insurance Brokers, Risk Consultants and Risk Managers based in PNG, providing excellent services to our clients based on sound, professional and ethical principles.</p>
				</div>
				<div class="col-md-4">
					<h2>Our Scope</h2>
					<p>The core of our business is to satisfy our customer needs for Insurance Products and Services, Risk Consultation and Risk Management</p>
				</div>
			</div>
			<div class="row values">
				<div class="col-md-8">
					<h2>Our Values</h2>
					<p>We strive to achieve our vision and goal by prompting the corporate values of:</p>
					<ul>
						<li>Financial Strength and Stability.</li>
						<li>Integrity and Dedication.</li>
						<li>Teamwork &amp; Effective Communication.</li>
						<li>Innovators and Creativity.</li>
						<li>Training and Personal Development.</li>
						<li>Planning, Accountability and Rewards directly linked to results oriented performance.</li>
					</ul>
				</div>
				<div class="col-md-4">
					<h2>&nbsp;</h2>
					<p>Promoting and effectively stewarding of these values will foster and environment of mutual trust, respect and partnership in which every employee will be encouraged to meaningfully contribute and discharge their duties and responsibilities to their full potential.</p>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section service-section" id="service">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<p class="lead">We specialize in tailor made risk management solutions for our valuable customers insurance needs. kanda international provides  the following insurance products and services to meet changing market needs</p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">
				<h2>General Insurance</h2>
				<p>For over 10-years, Kanda have been leaders in risk advice and general insurance and providing solutions for financial exposures for our local and overseas customers.</p>
				<p><a href="/services.php">read more &rarr;</a></p>
			</div>
			<div class="col-md-4">
				<h2>Life Insurance</h2>
				<p>At Kanda we understand that everyone has different life insurance needs based on their situation and stage in life. That's why our products are designed to be flexible so that they can be tailored to suit the ever changing needs.</p>
				<p><a href="/services.php">read more &rarr;</a></p>
			</div>
			<div class="col-md-4">
				<h2>Claim Services</h2>
				<p>At Kanda International Insurance brokers, we pride ourselves on the way we support our business and personal clients when they need to make a claim. we understand that even the smallest claim can be a worry and a hassle. That is why we are aways available for help. </p>
				<p><a href="/services.php">read more &rarr;</a></p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">
				<h2>Risk Consulting</h2>
				<p>Our Services will be available in the areas of Risk Surveys and Risk Improvement Advice. We can plan full Self Insurances Programs designed to meet your specific need.</p>
				<p><a href="/services.php">read more &rarr;</a></p>
			</div>
			<div class="col-md-4">
				<h2>Premium Funding</h2>
				<p>We have facilities available with Banks and Finance Institutions where premium can be obtained at very competitive rates. The procedure is very simple and is free of collateral. </p>
				<p><a href="/services.php">read more &rarr;</a></p>
			</div>
		</div>
	</div>
</section>
<section class="section staff-section" id="staff">
	<div class="slide">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="profile-box">
						<img src="images/staff/benn.jpg" alt="">
						<h3>Benn Piani Tiki <span>ANZIIF (Fellow) CIP, BCOM, MBA</span> <small>CEO &amp; Managing Director</small></h3>
						<p>Mr. Tiki is accredited with the most prestigious Fellow award and a Certified Insurance Professional of the Australia and New Zealand Institute of Insurance and Finance with over twenty five (25) years' experience in the Insurance Industry. Mr. Tiki also holds a Masters In Business Administration (MBA) with the Divine Word University.</p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="profile-box">
						<img src="images/staff/igo.jpg" alt="">
						<h3>Igo Rahe <span>ANZIIF (Assoc) CIP</span> <small>Account Manager</small></h3>
						<p>Igo is a Certified Insurance Professional and an Associate of the Australian and New Zealand Institute of Insurance and Finance Institute. He has over twenty five(25) years experience in the industry.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="slide">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="profile-box">
						<img src="images/staff/paulina.jpg" alt="">
						<h3>Paulina Peter <span>ANZIIF (Snr.Assoc) CIP</span> <small>Account Manager</small></h3>
						<p>Paulina is our account Manager. She is a member of ANZIIF at Senior Associate level and attained qualifications in both Diploma of Insurance Broking and Diploma in General Insurance. She is in insurance broking spans a period of more than 30 years working for two global broking firms.</p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="profile-box">
						<img src="images/staff/shamal.jpg" alt="">
						<h3>Shamal Arumapperuma <span>ANZIIF (Associate) CIP</span> <small>SME Account &amp; Quality Assurance Manager</small></h3>
						<p>Shamal has a total of over 10 years Industry experiences as well as client servicing both locally and overseas. He is a Member of the Sri lanka insurance institute. He is qualified Diploma in Insurance (Practicing &amp; Technical) & Diploma in Computer studies as well.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="slide">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="profile-box">
						<img src="images/staff/richard.jpg" alt="">
						<h3>Richard Melegepa <small>Insurance Broker</small></h3>
						<p>Richard has 12 years' experience in the Insurance Industry, 6 of which as an Insurance Broker. Working under Account Manager Igo Rahe, his inclusion into our team from AON Risks Services (PNG) Ltd is an added advantage to servicing and adequately meeting our clients' insurance needs.</p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="profile-box">
						<img src="images/staff/zuggie.jpg" alt="">
						<h3>Zuggie Barry <small>Account Broker</small></h3>
						<p>Zuggie has 10 years' experience in the Insurance Industry, he is a account broker Working under SME & QA Manager Shamal Arumapperuma, He is also a certified insurance professional and hold an Associate membership of the Australian & New Zealand Institute of Insurance and Finance.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="slide">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="profile-box">
						<img src="images/staff/tom.jpg" alt="">
						<h3>Tom Kune</h3>
						<p>He is our Lae Office Manager. He has over thirty (30) years experience in the Insurance Industry. He has been a Senior Insurance Broker with International Insurance companies he worked for.</p>
					</div>
				</div>
				<div class="col-md-6">
					<div class="profile-box">
						<img src="images/staff/kolwai.jpg" alt="">
						<h3>Kolwai Nenggai <span>ANZIIF (Assoc) CIP</span></h3>
						<p>He has over 25 years experience in the insurance industry in both the role of underwriting and broking. He is also a certified insurance professional and hold an Associate membership of the Australian &amp; New Zealand Institute of Insurance and Finance</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="section contact-section" id="contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<p>Thank you for visiting our web site. We at Kanda international are committed to provide you of our best service every time. Your feedback and suggestions about our products and services are more important for us to serve you even better.</p>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4">
				<b>HEAD OFFICE - PORT MORESBY</b><br>
				Address: Level2, First heritage Centre, Waigani<br>
				Postal Address: P O Box 1330, Port Moresby,NCD<br>
				TELEPHONE: (675) 323 9572 / 323 9643 /323 9849<br>
				MOBILE: (675) 7686 3562 / 7686 9453<br>
				FAX: (675) 323 9535<br>
				EMAIL: btiki@kanda.com.pg
			</div>
			<div class="col-md-8">
				<b>LAE OFFICE</b><br>
				Address: Suite 1 - 6, Level 1, IPI Building, 2nd Street LAE<br>
				Postal Address: P.O Box 2328, Lae 411, Morobe Province<br> 
				TELEPHONE: (675) 472 8474<br>
				FAX: (675) 472 8547<br>
				EMAIL: tkune@telinet.com.pg
			</div>
		</div>
	</div>
</section>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/vendors/jquery.easings.min.js"></script> 
<script src="js/vendors/jquery.slimscroll.min.js"></script>
<script src="js/jquery.fullPage.min.js"></script>
<script src="js/skrollr.min.js"></script>
<script type="text/javascript">
$(function(){
	var s = skrollr.init();
	if($(document).width()>480){
		$('#intro').addClass('down');
		 $('#kanda').fullpage({
		 	slidesColor: ['#1175b9', '#1175b9', '#7BAABE', '#1175b9', '#ccddff', '#1bbc9b'],
			anchors: ['home', 'whykanda', 'aboutus', 'services', 'ourstaff', 'contactus'],
			menu: '#menu',
			afterLoad: function(anchorLink, index){
				if(index == '1'){
	                $('.navbar-brand').removeClass('active');
	            }

	            if(index > '1'){
	                $('.navbar-brand').addClass('active');
	            }
			},
			afterRender: function(){
				$('#kanda-home').addClass('slide');
	            $('#loading').fadeOut(function(){
	            	$('#intro').removeClass('down');
	            });
	        }
		 });
	 }
});
</script>
</body>
</html>